<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>View Matches</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <h1>Cricket Management System</h1>
</header>
<nav>
    <a href="add_team.php">Add Team</a>
    <a href="add_player.php">Add Player</a>
    <a href="delete_player.php">Delete Player</a>
    <a href="assign_captain.php">Assign Captain</a>
    <a href="add_match.php">Add Match</a>
    <a href="set_winner.php">Set Winner</a>
    <a href="view_players.php">View Players</a>
    <a href="view_matches.php">View Matches</a>
</nav>
<div class="container">
<h2>All Matches</h2>
<table border='1' cellpadding='10'>
<tr><th>ID</th><th>Team 1</th><th>Team 2</th><th>Date</th><th>Winner</th></tr>
<?php
$result = $conn->query("
    SELECT m.id, t1.name as team1, t2.name as team2, m.match_date, tw.name as winner 
    FROM matches m
    JOIN teams t1 ON m.team1_id = t1.id
    JOIN teams t2 ON m.team2_id = t2.id
    LEFT JOIN teams tw ON m.winner_id = tw.id
    ORDER BY m.id DESC
");
while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['team1']}</td>
            <td>{$row['team2']}</td>
            <td>{$row['match_date']}</td>
            <td>" . ($row['winner'] ? $row['winner'] : 'TBD') . "</td>
          </tr>";
}
?>
</table>
</div>
<footer>
    <p>&copy; 2025 Cricket Management System. All rights reserved.</p>
</footer>
</body>
</html>