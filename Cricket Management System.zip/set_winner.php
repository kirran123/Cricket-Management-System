<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Cricket Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <h1>Cricket Management System</h1>
</header>
<nav>
    <a href="add_team.php">Add Team</a>
    <a href="add_player.php">Add Player</a>
    <a href="delete_player.php">Delete Player</a>
    <a href="assign_captain.php">Assign Captain</a>
    <a href="add_match.php">Add Match</a>
    <a href="set_winner.php">Set Winner</a>
    <a href="view_players.php">View Players</a>
    <a href="view_matches.php">View Matches</a>
</nav>
<div class="container">

<!DOCTYPE html>
<html>
<head><title>Set Winner</title></head>
<body>
<h2>Set Match Winner</h2>
<form method="post">
    Match ID: <input type="number" name="match_id" required><br>
    Winning Team ID: <input type="number" name="winner_id" required><br>
    <input type="submit" value="Set Winner">
</form>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $match_id = $_POST['match_id'];
    $winner_id = $_POST['winner_id'];
    $conn->query("UPDATE matches SET winner_id=$winner_id WHERE id=$match_id");
    echo "Winner updated.";
}
?>

</body>
</html>
</div>
<footer>
    <p>&copy; 2025 Cricket Management System. All rights reserved.</p>
</footer>

</body>
</html>
