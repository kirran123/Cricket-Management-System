<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Cricket Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <h1>Cricket Management System</h1>
</header>
<nav>
    <a href="add_team.php">Add Team</a>
    <a href="add_player.php">Add Player</a>
    <a href="delete_player.php">Delete Player</a>
    <a href="assign_captain.php">Assign Captain</a>
    <a href="add_match.php">Add Match</a>
    <a href="set_winner.php">Set Winner</a>
    <a href="view_players.php">View Players</a>
    <a href="view_matches.php">View Matches</a>
</nav>
<div class="container">

<!DOCTYPE html>
<html>
<head><title>Add Player</title></head>
<body>
<h2>Add Player</h2>
<form method="post">
    Player Name: <input type="text" name="name" required><br>
    Team:
    <select name="team_id">
        <?php
        $teams = $conn->query("SELECT * FROM teams");
        while ($team = $teams->fetch_assoc()) {
            echo "<option value='{$team['id']}'>{$team['name']}</option>";
        }
        ?>
    </select><br>
    <input type="submit" value="Add Player">
</form>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $team_id = $_POST['team_id'];
    $conn->query("INSERT INTO players (name, team_id) VALUES ('$name', $team_id)");
    echo "Player added.";
}
?>

</body>
</html>
</div>
<footer>
    <p>&copy; 2025 Cricket Management System. All rights reserved.</p>
</footer>

</body>
</html>
