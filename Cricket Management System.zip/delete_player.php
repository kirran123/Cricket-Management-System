<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Cricket Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <h1>Cricket Management System</h1>
</header>
<nav>
    <a href="add_team.php">Add Team</a>
    <a href="add_player.php">Add Player</a>
    <a href="delete_player.php">Delete Player</a>
    <a href="assign_captain.php">Assign Captain</a>
    <a href="add_match.php">Add Match</a>
    <a href="set_winner.php">Set Winner</a>
    <a href="view_players.php">View Players</a>
    <a href="view_matches.php">View Matches</a>
</nav>
<div class="container">

<!DOCTYPE html>
<html>
<head><title>Delete Player</title></head>
<body>
<h2>Delete Player</h2>
<form method="post">
    Player ID: <input type="number" name="id" required>
    <input type="submit" value="Delete Player">
</form>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $conn->query("DELETE FROM players WHERE id=$id");
    echo "Player deleted.";
}
?>

</body>
</html>
</div>
<footer>
    <p>&copy; 2025 Cricket Management System. All rights reserved.</p>
</footer>


</body>
</html>
