<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Cricket Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <h1>Cricket Management System</h1>
</header>
<nav>
    <a href="add_team.php">Add Team</a>
    <a href="add_player.php">Add Player</a>
    <a href="delete_player.php">Delete Player</a>
    <a href="assign_captain.php">Assign Captain</a>
    <a href="add_match.php">Add Match</a>
    <a href="set_winner.php">Set Winner</a>
    <a href="view_players.php">View Players</a>
    <a href="view_matches.php">View Matches</a>
</nav>
<div class="container">

<!DOCTYPE html>
<html>
<head><title>View Players</title></head>
<body>
<h2>All Players</h2>
<table border='1' cellpadding='10'>
<tr><th>ID</th><th>Name</th><th>Team</th><th>Captain</th></tr>
<?php
$result = $conn->query("SELECT players.*, teams.name AS team_name FROM players LEFT JOIN teams ON players.team_id = teams.id");
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['team_name']}</td><td>" . ($row['is_captain'] ? "Yes" : "No") . "</td></tr>";
}
?>
</table>

</body>
</html>
</div>
<footer>
    <p>&copy; 2025 Cricket Management System. All rights reserved.</p>
</footer>

