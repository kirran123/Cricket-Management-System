<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Cricket Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <h1>Cricket Management System</h1>
</header>
<nav>
    <a href="add_team.php">Add Team</a>
    <a href="add_player.php">Add Player</a>
    <a href="delete_player.php">Delete Player</a>
    <a href="assign_captain.php">Assign Captain</a>
    <a href="add_match.php">Add Match</a>
    <a href="set_winner.php">Set Winner</a>
    <a href="view_players.php">View Players</a>
    <a href="view_matches.php">View Matches</a>
</nav>
<div class="container">

<!DOCTYPE html>
<html>
<head><title>Add Match</title></head>
<body>
<h2>Add Match</h2>
<form method="post">
    Team 1:
    <select name="team1">
        <?php
        $teams = $conn->query("SELECT * FROM teams");
        while ($t = $teams->fetch_assoc()) {
            echo "<option value='{$t['id']}'>{$t['name']}</option>";
        }
        ?>
    </select><br>
    Team 2:
    <select name="team2">
        <?php
        $teams->data_seek(0);
        while ($t = $teams->fetch_assoc()) {
            echo "<option value='{$t['id']}'>{$t['name']}</option>";
        }
        ?>
    </select><br>
    Match Date: <input type="date" name="date" required><br>
    <input type="submit" value="Add Match">
</form>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $team1 = $_POST['team1'];
    $team2 = $_POST['team2'];
    $date = $_POST['date'];
    $conn->query("INSERT INTO matches (team1_id, team2_id, match_date) VALUES ($team1, $team2, '$date')");
    echo "Match added.";
}
?>

</body>
</html>
</div>
<footer>
    <p>&copy; 2025 Cricket Management System. All rights reserved.</p>
</footer>

</body>
</html>
